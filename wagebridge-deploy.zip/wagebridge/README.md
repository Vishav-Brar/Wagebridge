# WageBridge — Smart Wage Management MVP

A responsive fintech prototype for Indian workers and employers. Includes a React + TypeScript + Tailwind frontend, interactive role-based demo workspaces, local browser persistence, downloadable wage statement, founder photo upload placeholders, and an Express + Prisma + PostgreSQL API scaffold.

## Quick start

Requirements: Node.js 20+, npm. For the API/database, PostgreSQL 14+.

```bash
npm install
npm run dev
```
Open http://localhost:5173. Demo sign-in accepts any email containing `worker`, `employer`, or `admin`; password is `demo1234`.

### Run the backend (optional)

```bash
cp .env.example .env
# Update DATABASE_URL and JWT_SECRET in .env
npm run db:generate
npm run db:migrate
npm run db:seed
npm run server
```
API health check: http://localhost:4000/api/health

## Demo flows

- Worker: request up to ₹4,500 of already-earned wages (Rajesh example); request enters employer review queue.
- Employer: add workers, search employees, adjust attendance, inspect estimated payroll, approve/reject requests.
- Worker: inspect wallet and transaction history; download a text wage statement.
- Admin: inspect seeded platform-level illustrative metrics.
- Founders: upload/replace each of five portrait files independently; edit names, roles, bios and optional LinkedIn URLs. Data is saved in this browser's localStorage.

## Prototype boundaries

- Frontend demo mode persists state in `localStorage`; clearing browser storage resets it. Demo sign-in is intentionally not production authentication.
- The Express API scaffold uses bcrypt password hashing, JWT role checks, Zod validation and Prisma/PostgreSQL. It is a starter API, not a complete audited production deployment.
- No real bank transfer, payment rail, credit decision, or disbursement is performed. Balances and transactions are simulated.
- Sample statistics, dates, plan prices and user data are illustrative. Proposed pricing is not an offer.
- No RBI authorization or regulatory approval is claimed. Obtain legal, compliance, security and partner review before handling real money or personal financial data.

## Architecture

`src/` React UI and browser demo persistence · `server/src/` Express API · `server/prisma/` PostgreSQL data model and demo seed.

## Deploy the prototype

This repository can be deployed as a **static interactive demo** (not a production financial service):

- **Vercel:** import this repository, use the default Vite build, or keep the included `vercel.json` (`npm run build`, output `dist`).
- **Netlify:** import this repository; the included `netlify.toml` sets the build command and publish directory.
- **Docker:** run `docker build -t wagebridge-demo .` then `docker run --rm -p 8080:80 wagebridge-demo` and open http://localhost:8080.

The static frontend uses browser `localStorage` and demo role selection. It does not connect to the Express API, authenticate users securely, or move money. Do not use it with real worker records, credentials, bank details, or financial transactions. The API scaffold is not production-hardened; before using it, implement server-derived wage eligibility, production authentication and secrets, complete role-scoped data access, audit logging, payment-provider integration, privacy controls, and independent security/compliance review. The API requires a separately provisioned PostgreSQL database and is not included in the static hosting configuration.

### Demo accounts

Use `worker@wagebridge.in`, `employer@wagebridge.in`, or `admin@wagebridge.in` with any password in the prototype sign-in screen. This is role selection only, not real authentication.
